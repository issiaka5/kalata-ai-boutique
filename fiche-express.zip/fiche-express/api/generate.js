// Fonction serveur Vercel : la clé API reste ici, jamais dans la page.
const MODEL = process.env.MODEL || "claude-haiku-5-5";
const CODES = (process.env.ACCESS_CODES || "").split(",").map(s => s.trim()).filter(Boolean);
const DAILY_LIMIT = parseInt(process.env.DAILY_LIMIT || "30", 10);
const usage = new Map(); // limite simple (remise à zéro si le serveur redémarre)

function countFor(code) {
  const day = new Date().toISOString().slice(0, 10);
  const k = code + "|" + day;
  const n = usage.get(k) || 0;
  return { k, n };
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Méthode non autorisée." });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: "Serveur mal configuré : clé API manquante." });

  const { code, name, price, network, image } = req.body || {};
  const c = String(code || "").trim();
  if (!c || !CODES.includes(c)) return res.status(401).json({ error: "Code d’accès invalide. Contacte le vendeur du service." });
  if (!name || String(name).length > 200) return res.status(400).json({ error: "Nom du produit manquant ou trop long." });
  if (image && String(image).length > 1500000) return res.status(413).json({ error: "Image trop lourde." });

  const { k, n } = countFor(c);
  if (n >= DAILY_LIMIT) return res.status(429).json({ error: "Limite du jour atteinte pour ce code. Reviens demain." });

  const prompt =
    "Tu es un expert en vente sur WhatsApp et réseaux sociaux pour les petits commerçants de Côte d’Ivoire. " +
    "Écris en français simple, chaleureux, sans fautes, sans jargon. N’invente aucune caractéristique que tu ne vois pas sur la photo ou que le vendeur n’a pas donnée.\n" +
    "Produit : " + String(name) + "\n" +
    "Prix : " + (price ? String(price) + " FCFA" : "non précisé") + "\n" +
    "Réseau : " + String(network || "Instagram") + "\n" +
    "Réponds UNIQUEMENT avec un objet JSON, sans texte autour, avec ces clés :\n" +
    "\"description\" : 2 à 3 phrases vendeuses (matière, usage, avantage visibles ou donnés).\n" +
    "\"whatsapp\" : message prêt à envoyer, avec 2 ou 3 émojis, le prix si connu, et une invitation à écrire pour commander, livraison possible.\n" +
    "\"post\" : légende adaptée au réseau choisi, avec appel à l’action et 5 hashtags pertinents.\n" +
    "\"prix\" : une phrase courte qui aide à fixer le prix, ou « Prix déjà indiqué » s’il est donné.";

  const content = [];
  if (image) content.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: String(image) } });
  content.push({ type: "text", text: prompt });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 1000, messages: [{ role: "user", content }] })
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: "Erreur du service IA. Réessaie dans un instant." });
    const text = (data.content || []).map(b => b.text || "").join("").replace(/```json|```/g, "").trim();
    const out = JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1));
    usage.set(k, n + 1);
    return res.status(200).json(out);
  } catch (e) {
    return res.status(500).json({ error: "Impossible de générer la fiche. Réessaie." });
  }
};
