# Fiche Express – mise en ligne avec ta clé API

## 1. Clé API
1. Va sur console.anthropic.com, crée un compte et ajoute un peu de crédit (5 $ suffisent pour démarrer).
2. Crée une clé API (« API Keys »). Copie-la, ne la mets JAMAIS dans index.html.

## 2. Mettre le projet en ligne (Vercel, gratuit)
1. Crée un dépôt GitHub (ex. fiche-express) et envoie-y ces fichiers : `index.html`, `package.json`, dossier `api/` avec `generate.js`.
2. Sur vercel.com, connecte-toi avec GitHub, clique « Add New Project » et choisis le dépôt.
3. Avant de valider, ouvre « Environment Variables » et ajoute :
   - `ANTHROPIC_API_KEY` = ta clé API
   - `ACCESS_CODES` = codes séparés par des virgules, ex. `ESSAI-2026,AMINATA-7Q3,KOFFI-4X9`
   - `DAILY_LIMIT` = 30 (générations par jour et par code, facultatif)
   - `MODEL` = `claude-haiku-5-5` (facultatif, c’est le modèle le moins cher)
4. Clique « Deploy ». Ton lien sera du type `fiche-express.vercel.app`.

## 3. Vendre
- Un client = un code. Envoie le code après paiement Wave/Orange Money (2 000 à 3 000 FCFA/mois).
- Pour couper un client : retire son code de `ACCESS_CODES` dans Vercel et redéploie.
- Donne un code `ESSAI-…` aux testeurs pendant 1 semaine.

## Limites actuelles
- Le compteur journalier est en mémoire : il peut se remettre à zéro quand le serveur redémarre. Suffisant pour démarrer ; pour du solide, ajoute une base (Vercel KV).
- Surveille ta consommation sur console.anthropic.com et fixe une limite mensuelle de dépense.
